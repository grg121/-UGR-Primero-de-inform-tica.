#include<iostream>
#include<cmath>
using namespace std;
int main(){
	double capital_inicial;
	double interes;
    long double total_acumulado;
	int total_years;
	int contador;
	int year_number;
	double cantidad_final_acumulada;
	cout << " Introduce el capital ingresado " ;
	cin >> capital_inicial ;
	cout << " Introduce el inter�s en cuesti�n (tanto por ciento): " ;
	cin >> interes;
	cout << " Introduce el n�mero de a�os a calcular: ";
	cin >> total_years;
	contador = total_years - 1;
    year_number = 2;
    total_acumulado = capital_inicial + capital_inicial * interes;
    cout << "\nEl valor total acumulado el a�o numero 1 es de: " << total_acumulado;
    cantidad_final_acumulada = total_acumulado;
	while (contador != 0 ){
	total_acumulado = total_acumulado + total_acumulado * interes/100;
	cout << "\nEl valor total acumulado el a�o numero " << year_number << " es de " << total_acumulado << "\n";
	cantidad_final_acumulada = cantidad_final_acumulada + total_acumulado;
	contador-- ;
	year_number++ ;
    }
cout << "la cantidad final acumulada ( a lo largo de todos los a�os estudiados) es de: " << cantidad_final_acumulada;
}
