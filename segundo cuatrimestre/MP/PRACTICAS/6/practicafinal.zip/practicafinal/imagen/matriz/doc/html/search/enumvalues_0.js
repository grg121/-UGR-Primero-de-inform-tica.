var searchData=
[
  ['img_5fdesconocido',['IMG_DESCONOCIDO',['../pgm_8h.html#a8914f6544a484741b05c092d9e7522eda23c8d70e6eadf2d0d0ee1fd3bb293384',1,'pgm.h']]],
  ['img_5fpgm_5fbinario',['IMG_PGM_BINARIO',['../pgm_8h.html#a8914f6544a484741b05c092d9e7522eda724f6134dce25e3d82af96f9061dd9de',1,'pgm.h']]],
  ['img_5fpgm_5ftexto',['IMG_PGM_TEXTO',['../pgm_8h.html#a8914f6544a484741b05c092d9e7522eda2535c521166366e04b5091ef8acfcbde',1,'pgm.h']]]
];
