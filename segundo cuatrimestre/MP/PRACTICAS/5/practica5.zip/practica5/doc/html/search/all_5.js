var searchData=
[
  ['filas',['filas',['../classImagen.html#ae7ef85a5d548e01c9a1f2ce35d4951d8',1,'Imagen']]]
];
