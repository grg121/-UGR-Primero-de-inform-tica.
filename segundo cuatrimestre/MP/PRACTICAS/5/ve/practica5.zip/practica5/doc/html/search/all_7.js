var searchData=
[
  ['imagen',['Imagen',['../classImagen.html',1,'Imagen'],['../classImagen.html#ab2e649aa7a105155c7bfdb846abf0528',1,'Imagen::Imagen()'],['../classImagen.html#a7632978f5ae089713e652bb362da1e78',1,'Imagen::Imagen(int filas, int columnas)']]],
  ['imagen_2eh',['imagen.h',['../imagen_8h.html',1,'']]],
  ['img_5fdesconocido',['IMG_DESCONOCIDO',['../pgm_8h.html#a8914f6544a484741b05c092d9e7522eda23c8d70e6eadf2d0d0ee1fd3bb293384',1,'pgm.h']]],
  ['img_5fpgm_5fbinario',['IMG_PGM_BINARIO',['../pgm_8h.html#a8914f6544a484741b05c092d9e7522eda724f6134dce25e3d82af96f9061dd9de',1,'pgm.h']]],
  ['img_5fpgm_5ftexto',['IMG_PGM_TEXTO',['../pgm_8h.html#a8914f6544a484741b05c092d9e7522eda2535c521166366e04b5091ef8acfcbde',1,'pgm.h']]],
  ['infopgm',['infoPGM',['../pgm_8h.html#a85c7f15bdcdee461eba76965aaccb910',1,'infoPGM(const char nombre[], int &amp;filas, int &amp;columnas):&#160;pgm.cpp'],['../pgm_8cpp.html#a85c7f15bdcdee461eba76965aaccb910',1,'infoPGM(const char nombre[], int &amp;filas, int &amp;columnas):&#160;pgm.cpp']]],
  ['insertar',['insertar',['../classLista.html#a2cf31ee7be6ed41e9084efffb807aa5e',1,'Lista']]]
];
