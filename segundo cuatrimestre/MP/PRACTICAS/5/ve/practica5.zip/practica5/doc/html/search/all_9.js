var searchData=
[
  ['off',['off',['../byte_8h.html#ac3159ec165abb36940406f8d9296ba22',1,'byte.cpp']]],
  ['on',['on',['../byte_8h.html#a4719ceb95ce32bfb82d1e47d33f58fef',1,'byte.cpp']]]
];
